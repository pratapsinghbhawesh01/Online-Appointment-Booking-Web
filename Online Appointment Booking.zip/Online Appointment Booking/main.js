let DB;

let form = document.querySelector('form');
let employeeName = document.querySelector('#employee-name');
let contact = document.querySelector('#contact');
let date = document.querySelector('#date');
let time = document.querySelector('#time');
let reasons = document.querySelector('#reasons');
let meetings = document.querySelector('#meetings');
let services = document.querySelector('#services');

document.addEventListener('DOMContentLoaded', () => {
     // create the database
     let ScheduleDB = window.indexedDB.open('meetings', 1);

     // if there's an error
     ScheduleDB.onerror = function() {
          console.log('error');
     }
     // if everything is fine, assign the result is to the (letDB) instance 
     ScheduleDB.onsuccess = function() {
           

          
          DB = ScheduleDB.result;

          showMeetings();
     }

   
     ScheduleDB.onupgradeneeded = function(e) {
          
          let db = e.target.result;
          
          let objectStore = db.createObjectStore('meetings', { keyPath: 'key', autoIncrement: true } );

        
          objectStore.createIndex('employeename', 'employeename', { unique: false } );
          objectStore.createIndex('contact', 'contact', { unique: false } );
          objectStore.createIndex('date', 'date', { unique: false } );
          objectStore.createIndex('time', 'time', { unique: false } );
          objectStore.createIndex('reasons', 'reasons', { unique: false } );

           
     }

     form.addEventListener('submit', addMeetings);

     function addMeetings(e) {
          e.preventDefault();
          let newMeeting = {
               employeename : employeeName.value,
               
             contact : contact.value,
               date : date.value,
            time : time.value,
               reasons : reasons.value
          }
          
          let transaction = DB.transaction(['meetings'], 'readwrite');
          let objectStore = transaction.objectStore('meetings');

          let request = objectStore.add(newMeeting);
                    request.onsuccess = () => {
               form.reset();
          }
          transaction.oncomplete = () => {
            

               showMeetings();
          }
          transaction.onerror = () => {
                
          }

     }
     function showMeetings() {
       
          while(meetings.firstChild) {
            meetings.removeChild(meetings.firstChild);
          }
         
          let objectStore = DB.transaction('meetings').objectStore('meetings');

          objectStore.openCursor().onsuccess = function(e) {
               
               let cursor = e.target.result;
               if(cursor) {
                    let MeetingHTML = document.createElement('li');
                    MeetingHTML.setAttribute('data-meeting-id', cursor.value.key);
                    MeetingHTML.classList.add('list-group-item');
                    
                 
                    MeetingHTML.innerHTML = `  
                         <p class="font-weight-bold">Employee Name:  <span class="font-weight-normal">${cursor.value.employeename}<span></p>
                          <p class="font-weight-bold">Contact:  <span class="font-weight-normal">${cursor.value.contact}<span></p>
                         <p class="font-weight-bold">Date:  <span class="font-weight-normal">${cursor.value.date}<span></p>
                         <p class="font-weight-bold">Time:  <span class="font-weight-normal">${cursor.value.time}<span></p>
                         <p class="font-weight-bold">Reasons:  <span class="font-weight-normal">${cursor.value.reasons}<span></p>
                    `;

                    
                    const cancelBtn = document.createElement('button');
                    cancelBtn.classList.add('btn', 'btn-danger');
                    cancelBtn.innerHTML = 'Cancel';
                    cancelBtn.onclick = removeMeeting;
               
                 
                    MeetingHTML.appendChild(cancelBtn);
                 meetings.appendChild(MeetingHTML);

                    cursor.continue();
               } else {
                    if(!meetings.firstChild) {
                        services.textContent = 'ᑕᕼᗩᑎGE YOᑌᖇ ᗰEETIᑎG ᔕᑕᕼEᗪᑌᒪE';
                         let noSchedule = document.createElement('p');
                         noSchedule.classList.add('text-center');
                         noSchedule.textContent = 'No results Found';
                         meetings.appendChild(noSchedule);
                    } else {
                        services.textContent = 'ᑕᗩᑎᑕEᒪ YOᑌᖇ ᗰEETIᑎG'
                    }
               }
          }
     }

          function removeMeeting(e) {
       
          let scheduleID = Number( e.target.parentElement.getAttribute('data-meeting-id') );
         
          let transaction = DB.transaction(['meetings'], 'readwrite');
          let objectStore = transaction.objectStore('meetings');
         
          objectStore.delete(scheduleID);

          transaction.oncomplete = () => {
             
               e.target.parentElement.parentElement.removeChild( e.target.parentElement );

               if(!meetings.firstChild) {
                   
                    services.textContent = 'ᑕᕼᗩᑎGE YOᑌᖇ ᗰEETIᑎG ᔕᑕᕼEᗪᑌᒪE';
                   
                   let noSchedule = document.createElement('p');
                  
                   noSchedule.classList.add('text-center');
                   
                   noSchedule.textContent = 'No results Found';
                
                    meetings.appendChild(noSchedule);
               } else {
                   services.textContent = 'ᑕᗩᑎᑕEᒪ YOᑌᖇ ᗰEETIᑎG'
               }
          }
     }

});